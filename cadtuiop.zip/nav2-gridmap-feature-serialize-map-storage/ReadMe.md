# Map Framework 

# Table of Contents
1. [Project Overview](#project-overview)
2. [Configuration Files](#configuration-files-)
3. [Installation](#installation)
4. [Run Examples](#run-examples)
    1. [Lidar 3D Gridmap Example](#lidar-3d-gridmap-example)
    2. [Lidar 3D Gridmap Example](#lidar-2d-gridmap-example)
    3. [RGB Camera Gridmap Example](#rgb-camera-gridmap-example)



## Project Overview 

The goal of this project is to develop a map framework that enables the creation of gridmaps using various sensors, including lidar (2D and 3D), cameras (RGB and stereo), and radar. The framework will generate three types of gridmaps: a fused static gridmap, an elevation map, and a dynamic fused gridmap. The static gridmap will be created by fusing lidar and RGB camera data, the elevation map will be generated using the ANYBotics mapping framework from stereo camera data, and the dynamic gridmap will be formed by fusing radar and dynamic obstacle data from the camera.

![](media/map_framework.png)

### Converting LIDAR and Camera data to GridMaps :

The lidar and camera to gridmap conversion processes generate gridmaps with distinct layers, including occupied, free, unknown, and combined. The occupied and free layers are populated using the sensor data, capturing the presence or absence of obstacles in the environment. The combined layer is then constructed by merging the occupied and free layers, providing a unified representation of the environment.

 To address areas where information is uncertain or unavailable, the static fusion module generates the unknown gridmap layer based on the combined layer. This is achieved by designating alternate grid cells as unknown, ensuring that regions with ambiguous data are adequately represented. In this gridmap representation, specific cost values are assigned to each layer: 255 for occupied cells, 0 for free cells, 150 for unknown cells, and -1 for cells that hold no specific meaning.

### Fused Static Map from the LIDAR and Camera GridMaps :

 Th static fusion module plays a crucial role in the map framework by fusing the individual lidar and camera gridmaps to create a comprehensive static fused gridmap. The primary objective of the static fusion module is to seamlessly merge the occupied and free layers derived from the sensor gridmaps and generate the combined and unknown layers. 
 
### Extended Map Server/Saver :

The framework also provides a nav2 compatible gridmap map server that can save and load a static gridmap. This loaded gridmap should also contain occupied, free, unknown, and combined layers. This gridmap (if loaded) is also passed to the static fusion module to form the fused static gridmap.

### Generating an Elevation Map from stereo camera data [drive](https://drive.google.com/drive/folders/1JALj7_i2yZvA2TAbesbQbv1AT12EN91z):

The framework generates an elevation gridmap by integrating a stereo camera into the framework. It contains nodes for pre-processing this data and passes it to the ANYBotics elevation mapping framework to generate an elevation gridmap.

### Converting Dynamic RADAR and Dynamic Obstacle data from Camera to GridMaps:

* TBD *

### Fused Dynamic Map from Dynamic RADAR and Dynamic Camera Obstacle GridMaps:

* TBD *


## Configuration files : 

The user can interface with this framework through multiple configs files providing varying levels of customization in each module. The provided config files include 

    map_framework.yaml
    sensors.yaml
    sensor_pre_processing.yaml
    lidar_gridmap.yaml
    camera_gridmap.yaml 
    static_fusion.yaml 
    dynamic radar_gridmap.yaml 
    dynamic_camera_gridmap.yaml
    dynamic_fusion.yaml
    extended_map_server.yaml

## Installation

Requirements 
- Gridmap c++ library

Build and install ws
```
mkdir -p map_framework_ws/src && cd map_framework_ws/src
git clone https://github.com/CombatRobotics/nav2-gridmap.git
cd ..
colcon build
source install/setup.bash
```

## Run examples 

### Lidar 3D Gridmap Example 

Set up the config file [lidar_gridmap.yaml](https://github.com/CombatRobotics/nav2-gridmap/blob/main/map_framework/lidar_gridmap/config/lidar_gridmap.yaml)
```
/lidar_3d_gridmap_node:
  ros__parameters:
    gridmap_frame: velo_link
    ground_cloud_topic: /ground
    obstacle_cloud_topic: /nonground
    lidar_3d_gridmap_topic: /lidar_3d_gridmap
    positionX: 0.0
    positionY: 0.0
    resolution: 0.5
    size_dimX: 50.0
    size_dimY: 50.0
```

Build the package after changing the config file and launch demo.
```
ros2 launch lidar_gridmap lidar_gridmap_demo.launch.py
```

Start the rosbags
```
ros2 bag play src/map_framework/sensors/rosbags/kitti_rosbag.db3 --loop
```

### Lidar 2D Gridmap Example 
Set up the config file [lidar_gridmap.yaml](https://github.com/CombatRobotics/nav2-gridmap/blob/main/map_framework/lidar_gridmap/config/lidar_gridmap.yaml)
```
/lidar_2d_gridmap_node:
  ros__parameters:
    gridmap_frame: base_link
    lidar_2d_gridmap_topic: /lidar_2d_gridmap
    output_scan_topic: /scan
    positionX: 0.0
    positionY: 0.0
    resolution: 0.1
    size_dimX: 10.0
    size_dimY: 10.0
```

Build the package after changing the config file and launch demo.
```
ros2 launch lidar_gridmap lidar_gridmap_demo.launch.py
```

Start the rosbags
```
ros2 bag play src/map_framework/sensors/rosbags/test_lidar_2d_node.db3 --loop
```

### RGB Camera Gridmap Example 
Set up the config file [camera_gridmap.yaml](https://github.com/CombatRobotics/nav2-gridmap/blob/main/map_framework/camera_gridmap/config/camera_gridmap.yaml)
```
/rgb_camera_gridmap_node:
  ros__parameters:
    road_cloud_topic: /ground
    nonroad_cloud_topic:  /nonground
    rgb_camera_gridmap_topic: /rgb_camera_gridmap
    gridmap_frame: velo_link
    positionX: 0.0
    positionY: 0.0
    resolution: 0.5
    size_dimX: 50.0
    size_dimY: 50.0
```

Build the package after changing the config file and launch demo.
```
ros2 launch lidar_gridmap camera_gridmap_demo.launch.py
```

Start the rosbags
```
ros2 bag play src/map_framework/sensors/rosbags/test_camera_gridmap_node.db3 --loop
```




